#ifndef CONFIG_H
#define CONFIG_H

#include "motor.h"
#include "utility.h"

#define NUM_MOTORS 1

extern Motor motors[NUM_MOTORS];

#endif // CONFIG_H